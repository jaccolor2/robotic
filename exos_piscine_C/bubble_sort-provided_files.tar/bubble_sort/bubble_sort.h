#ifndef BUBBLE_SORT_H
#define BUBBLE_SORT_H

#include <stddef.h>

void bubble_sort(int array[], size_t size);

#endif /* !BUBBLE_SORT_H */
