#ifndef LOOKUP_TABLE_H
#define LOOKUP_TABLE_H

void apply_lut(unsigned char mat[4][4], const unsigned char lut[256]);

#endif
