#ifndef NULL_TERMINATED_ARRAYS_H_
#define NULL_TERMINATED_ARRAYS_H_

void reverse_matrix(const char ***matrix);

#endif /* !NULL_TERMINATED_ARRAYS_H_ */
