#ifndef MY_STRCASECMP_H
#define MY_STRCASECMP_H

int my_strcasecmp(const char *s1, const char *s2);

#endif /* !MY_STRCASECMP_H */
