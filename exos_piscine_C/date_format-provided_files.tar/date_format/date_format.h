#ifndef DATE_FORMAT_H
#define DATE_FORMAT_H

char *date_format(const char *format);

#endif /* !DATE_FORMAT_H */
