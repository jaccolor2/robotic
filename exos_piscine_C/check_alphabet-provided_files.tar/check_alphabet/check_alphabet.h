#ifndef CHECK_ALPHABET_H
#define CHECK_ALPHABET_H

int check_alphabet(const char *str, const char *alphabet);

#endif /* !CHECK_ALPHABET_H */
