#ifndef SEVEN_INT_H
#define SEVEN_INT_H

int dump_ints(int *arr, const char *path);
int read_ints(int *arr, const char *path);

#endif /* SEVEN_INT_H */
