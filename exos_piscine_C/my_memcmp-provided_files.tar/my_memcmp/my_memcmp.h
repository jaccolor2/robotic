#ifndef MY_MEMCMP_H
#define MY_MEMCMP_H

#include <stddef.h>

int my_memcmp(const void *s1, const void *s2, size_t num);

#endif /* !MY_MEMCMP_H */
