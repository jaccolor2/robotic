#ifndef ELEMENT_COUNT_H
#define ELEMENT_COUNT_H

#include <stddef.h>

size_t element_count(int *begin, int *end);

#endif /* !ELEMENT_COUNT_H */
