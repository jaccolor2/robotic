#ifndef VMAX_PTR_H
#define VMAX_PTR_H

#include <stddef.h>

int vmax(const int *ptr, size_t size);

#endif /* VMAX_PTR_H */
