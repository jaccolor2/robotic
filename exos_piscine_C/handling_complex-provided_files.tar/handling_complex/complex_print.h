#ifndef COMPLEX_PRINT_H
#define COMPLEX_PRINT_H

#include "complex.h"

void print_complex(struct complex a);

#endif /* !COMPLEX_PRINT_H */
