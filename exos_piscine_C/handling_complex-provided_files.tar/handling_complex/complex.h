#ifndef COMPLEX_H
#define COMPLEX_H

struct complex
{
    float real;
    float img;
};

#endif /* !COMPLEX_H */
