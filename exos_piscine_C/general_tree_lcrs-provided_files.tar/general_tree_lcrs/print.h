#ifndef PRINT_H
#define PRINT_H

#include "gtree.h"

void gtree_print_preorder(struct gtree *root);

#endif /* !PRINT_H */
