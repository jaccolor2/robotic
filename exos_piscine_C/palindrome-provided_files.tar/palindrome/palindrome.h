#ifndef PALINDROME_H
#define PALINDROME_H

int palindrome(const char *s);

#endif /* !PALINDROME_H */
